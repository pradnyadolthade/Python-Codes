def DisplayNum():
    for num in range(1,11):
        print(num)


def main():
    DisplayNum()



if __name__ == "__main__":
    main()