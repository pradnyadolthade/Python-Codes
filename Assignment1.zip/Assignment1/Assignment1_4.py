def display():
    for val in range(5):
        print("Marvellous")


def main():
    display()



if __name__ == "__main__":
    main()