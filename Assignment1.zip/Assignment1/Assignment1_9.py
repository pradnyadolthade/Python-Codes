
def DisplayEven():
    for i in range(2,21,2):
        print(i,end=" ")



def main():
    print("First 10 Even Number are as follows :")
    DisplayEven()




if __name__ == "__main__":
    main()