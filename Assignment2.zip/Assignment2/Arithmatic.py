def Add(no1,no2):
    Ans = no1 + no2
    return Ans

def Sub(no1,no2):
    Ans = no1 - no2
    return Ans

def Mul(no1,no2):
    Ans = no1 * no2
    return Ans

def Div(no1,no2):
    Ans = no1 / no2
    return Ans